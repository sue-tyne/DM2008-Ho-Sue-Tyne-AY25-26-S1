let shape;
let fish;

function preload() {
  shape = loadModel('goldfish.obj', true);
}

function setup() {
  createCanvas(500, 500, WEBGL);
  fish = new tailRight(shape);
}

function draw() {
  background(80);
  ambientLight(200);
  directionalLight(255, 255, 255, 0, 0, -1);
  orbitControl();

  fish.update();
  fish.display();
}

class tailRight {
  constructor(model) {
    this.model = model;
    this.angle = 0;
    this.speed = 0.3;
    this.amplitude = 0.3;
    this.tailOffsetZ = 70; // adjust for your model’s midpoint
  }

  update() {
    this.angle = sin(frameCount * this.speed) * this.amplitude;
  }

  display() {
    fill('orange');
    noStroke();

    // // Draw body (stationary)
    // push();
    // fill(255, 165, 0, 90); // orange with alpha 150
    // model(this.model);
    // pop();

    // Draw tail (rotating)
    push();
    translate(0, 0, this.tailOffsetZ);
    rotateY(this.angle);
    translate(0, 0, -this.tailOffsetZ);

    // scale slightly smaller to hide overlap
    scale(1.5);
    model(this.model);
    pop();
  }
}


