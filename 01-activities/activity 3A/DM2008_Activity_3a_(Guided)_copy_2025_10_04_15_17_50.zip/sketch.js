// DM2008 — Activity 3a
// (Array Sampler, 25 min)

// 1. Create an array of colors (or other values)
//    You can make more than one array if you'd like
let palette = ["#fff9c4", "#fff59d", "#fff176", "#ffee58", "#fdd835"];
let greens = ["#a5d6a7", "#81c784", "#66bb6a", "#4caf50", "#388e3c"];
let x, y;
let currentIndex = 0;
let bgIndex = 0;

function setup() {
  createCanvas(400, 400);
  noStroke();
  x = random(width);
  y = random(height);
  bgIndex = floor(random(greens.length));
}

function draw() {
  background(greens[bgIndex]);

  fill(palette[currentIndex]);
  ellipse(x, y, 200);

  x += 1;
  if (x > width) x = 0;
}

function keyPressed() {
  // cycle ellipse color
  currentIndex = (currentIndex + 1) % palette.length;
  // also pick a new background green when any key is pressed
  bgIndex = floor(random(greens.length));
  x = random(width);
  y = random(height);
}

function mousePressed() {
    // Add a new random color to the end
    palette.push(color(random(255), random(255), random(255)));
  console.log(palette);
    
}

/* 
TODOs for students:
1. Replace colors with your own data (positions, text, sizes, etc).
2. Try mousePressed() instead of keyPressed().
3. Use push() to add new items, or splice() to remove them, then check how the sketch adapts.
4. Try looping through an array to visualize all the items within it instead of accessing one item at a time.
*/