// DM2008 — Activity 2b
// (Pattern Making, 40 min)

function setup() {
  createCanvas(400, 400);
  rectMode(CENTER)
}

function draw() {
  background("#EB7610");

  // Repeat the row 8 times down the screen
  for (let j = 0; j < 8; j++) {

    // ONE Horizontal row of shapes
    for (let i = 0; i < width; i += 50) {

      if (i % 100 == 0) {
        // black circles
        fill(0);
        ellipse(i + 5, 50 * j + 25, 10); 
      } else {
        // aquares turn red when "a" is pressed
        if (keyIsPressed && key === 'a') {
          fill("#CE2C2C");
        } else {
          fill(180);
        }
        noStroke();
        rect(i + 5, 50 * j + 25, 35);
      }
    }
  }


    // TODO: change ellipse to rect, triangle, or something else
    // TODO: try varying size instead of color


  // TODO: add one interaction (mouse or key) to change the rule
  // Example: if (mouseIsPressed) { fill(255, 0, 0); }
  

    //if (keyIsPressed) {
   // if (key === 'a') {
    //fill("#CE2C2C");
    // } else {
   // fill(0);

}