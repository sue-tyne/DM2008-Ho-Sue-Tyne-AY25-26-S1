let colorBtn, bgBtn, sizeSlider, shapeSelect;
let bgColor, shapeColor;

function setup() {
  createCanvas(600, 400);
  noStroke();
  textFont("Helvetica, Arial, sans-serif");

  // starting color
  shapeColor = color(random(255), random(255), random(255));
  bgColor = color(random(255), random(255), random(255));

  // Button: change color
  colorBtn = createButton("Change Color");
  colorBtn.position(50, height / 2 + 100);
  colorBtn.mousePressed(randomShapeColor);
  colorBtn.addClass('hoverCircleBtn');

  function randomShapeColor() {
    shapeColor = color(random(255), random(255), random(255));
  }

  bgBtn = createButton("Change Background");
  bgBtn.position(50, height / 2 + 150);
  bgBtn.mousePressed(randomBgColor);
  bgBtn.addClass('hoverBgBtn');


  function randomBgColor() {
    bgColor = color(random(255), random(255), random(255));
  }

  // Slider: controls size
  createP("Size")
    .position(width / 2 - 70, height / 2 + 87)
    .style("margin", "4px 0 0 16px");
  sizeSlider = createSlider(20, 220, 100, 1);
  sizeSlider.position(width / 2 - 60, height / 2 + 105);

  // Dropdown: choose shape
  createP("Shape")
    .position(width / 2 + 130, height / 2 + 95)
    .style("margin", "8px 0 0 16px");
  shapeSelect = createSelect();
  shapeSelect.position(width / 2 + 200, height / 2 + 105);
  shapeSelect.option("ellipse");
  shapeSelect.option("rect");
  shapeSelect.option("triangle");
}

function draw() {
  background(bgColor);

  push();
  translate(width * 0.65, height * 0.5);
  let s = sizeSlider.value();

  fill(shapeColor);

  // draw chosen shape
  let choice = shapeSelect.value();
  if (choice === "ellipse") {
    ellipse(-80, -20, s, s);
  } else if (choice === "rect") {
    rectMode(CENTER);
    rect(-80, -20, s, s);
  } else if (choice === "triangle") {
    triangle(-s * 1.4, s * 0.5, 0.8, -s * 0.5, s * 0.2, s * 0.5);
  }
  pop();
}
