// DM2008 — Activity 3b
// (One Function Wonder, 15 min)

let suns = [];

function setup() {
  createCanvas(400, 400);
  noStroke();

  // create a few suns
  for (let i = 0; i < 8; i++) {
    suns.push({
      x: random(width),
      y: random(height),
      size: random(40, 80),
      dx: random(-1, 1),
      dy: random(-1, 1)
    });
  }
}

function draw() {
  background("#94F5E4");

  // move & spawn more suns
  for (let s of suns) {
    mySun(s.x, s.y, s.size, s.size);

    // simple random drifting
    s.x += s.dx;
    s.y += s.dy;

    // wrap around edges instead of bouncing
    if (s.x > width) s.x = 0;
    if (s.x < 0) s.x = width;
    if (s.y > height) s.y = 0;
    if (s.y < 0) s.y = height;
  }

  // red sunflower to follow mouse
  myRedSun(mouseX, mouseY, 30, 30);
}

function mySun(x, y, w, h) {
  fill("#F5BA40");
  ellipse(x, y, w, h);

  push();
  translate(x, y);
  fill("#FFD966");
  for (let i = 0; i < 360; i += 30) {
    push();
    rotate(radians(i));
    ellipse(0, -w * 0.75, w / 6, w * 1.5);
    pop();
  }
  pop();
}

function myRedSun(x, y, w, h) {
  push();
  translate(x, y);
  fill("#CE2C2C");
  for (let i = 0; i < 360; i += 60) {
    push();
    rotate(radians(i));
    ellipse(0, -w * 0.9, w * 0.6, w * 1.8);
    pop();
  }
  pop();

  fill("#3B2E2E");
  ellipse(x, y, w, h);
}

 

// Example starter function:
// function myShape(x, y, s) {
//   ellipse(x, y, s, s);
// }