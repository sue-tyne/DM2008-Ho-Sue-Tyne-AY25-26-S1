// DDM2008
// Activity 1a

// Run the sketch, then click on the preview to enable keyboard
// Use the 'Option' ('Alt' on Windows) key to view or hide the grid
// Use the 'Shift' key to change overlays between black & white
// Write the code for your creature in the space provided

function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(0);
  
  fill("#DBB264");
  noStroke(0)
  triangle(100, 124, 200, 149, 200, 174)
  triangle(100, 200, 200, 155, 200, 199)
  ellipse(225, 176, 75)
  quad(270, 200, 249, 205, 320, 207, 386, 125)
  quad(270, 190, 230, 200, 290, 220, 336, 102)
  ellipse(276, 225, 100)

  
  helperGrid(); // do not edit or remove this line
}
