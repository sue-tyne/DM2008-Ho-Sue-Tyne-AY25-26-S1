// DM2008 – Activity 4a
// Bake a Cookie (30 min)

let cookie;

function setup() {
  createCanvas(400, 400);
  noStroke();
  cookie = new Cookie("chocolate", 120, width/2, height/2);
}

function draw() {
  background(230);
  cookie.show();
}

class Cookie {
  constructor(flavor, sz, x, y) {
    this.flavor = flavor;
    this.sz = sz;
    this.x = x;
    this.y = y;
  }

  show() {
    // cookie base; change base color based on flavour
    if (this.flavor === "chocolate") {
      fill(196, 146, 96);
    } else if (this.flavor === "mint") {
      fill(180, 255, 200); // light minty green
    } else if (this.flavor === "vanilla") {
      fill(240, 220, 170); // pale yellow
    }
    ellipse(this.x, this.y, this.sz);

    // 5 chocolate chips
    fill(60, 30, 0);
    ellipse(this.x - 20, this.y - 10, 10);
    ellipse(this.x + 25, this.y - 15, 10);
    ellipse(this.x - 30, this.y + 20, 10);
    ellipse(this.x + 10, this.y + 25, 10);
    ellipse(this.x, this.y, 10);
  }
}

  // Steps 5 & 6: Implement additional methods here
// Step 5: add movement (keyboard arrows)
  function keyPressed() {
  if (key === ' ') { // SPACE key
    cookie.x = random(100, width - 100);
    cookie.y = random(100, height - 100);
  }
  else if (keyCode === LEFT_ARROW) {
    cookie.x -= 50;
  }
  else if(keyCode === RIGHT_ARROW) {
    cookie.x += 50;
  }
  else if (keyCode === DOWN_ARROW) {
    cookie.y += 50;
  }
  else if (keyCode === UP_ARROW) {
    cookie.y -=50;
  }
    //change cookie based off keypressed
      if (key === 'C' || key === 'c') {
    cookie.flavor = "chocolate";
  } 
  else if (key === 'M' || key === 'm') {
    cookie.flavor = "mint";
  } 
  else if (key === 'V' || key === 'v') {
    cookie.flavor = "vanilla";
  }
}

// Step 6: add flavor randomizer (mouse click)
function mousePressed() {
  let flavours = ["chocolate", "mint", "vanilla"];
  cookie.flavor = random(flavours);
}